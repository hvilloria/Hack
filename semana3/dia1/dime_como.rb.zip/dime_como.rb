
a = "Hola"

puts "#{a.upcase.split(//).reverse}"
puts "#{a.split(//).reverse}"

=begin
se realiza la modificacion de la variable "a" a un array a traves de el metodo
split(//) y luego reverse para mostrarlo como un array de strings reverso, ademas
de la aplicacion de "upcase" en el caso requerido.
=end