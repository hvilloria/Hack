

a = 123

x = [nil, false, true, false, true, "0", a]

x.map! do |elem|
	elem=true
end

puts x
