x = [23, 44, 56, 67]

x.map! do |elem|
	elem **2
end

puts x


=begin
	
en este programa se realiza el metodo map! al array x y se realiza el cuadrado de modo
que pueda imprimir los valores requeridos.
	
=end