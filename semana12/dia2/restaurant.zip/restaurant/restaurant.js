var Waiter = require('./waiter');
var Client = require('./client');
var Table = require('./table')

var clients = [];
var tables = [];
var waiterZone= [];

function fillWaiter() {
  waiterZone.push(waiter = new Waiter('Robert')); 
}

function fillClient() {
    clients.push(client = new Client('Miguel'));
    clients.push(client = new Client('Edkaryd'));
    clients.push(client = new Client('Hosward'));
    clients.push(client = new Client('Nestor'));
    clients.push(client = new Client('Yense'));
    // ojo
    // return clients con posible variable par capturarlo
}

function fillTable() {
    tables.push(table = new Table('Empty'));
    tables.push(table = new Table('Empty'));
    tables.push(table = new Table('Empty'));
    tables.push(table = new Table('Empty'));
}

function assingTables() {



    // if (clients.length  > 0){
    //   for (i = 0; i <= tables.length; i++){
    //
    //   }
    // }
}

fillTable();
fillClient();
fillWaiter();
assingTables();

console.log(clients);
console.log(tables);
console.log(waiter)
console.log(waiterZone);
