function Waiter(name){
  this.name = name;
}

Waiter.prototype.mostrar = function(){
  console.log("nombre: " + this.name);
}
module.exports = Waiter;
