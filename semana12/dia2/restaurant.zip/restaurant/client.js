function Client(name){
  this.name = name;
}


module.exports = Client
