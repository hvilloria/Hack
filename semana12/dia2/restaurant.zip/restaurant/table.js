function Table(number){
  this.number = number;
}



module.exports = Table;
