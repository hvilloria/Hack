var Waiter = require('./waiter');
var Client = require('./client');
var Restaurant = require('./restaurant');

function main(){

}
