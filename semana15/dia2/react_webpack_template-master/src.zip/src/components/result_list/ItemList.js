import React, { Component } from 'react';
import Item from './Item';

class ItemList extends Component {
  constructor(){
    super();
  }

  componentDidMount(){
    console.log(this.props.onSearch)
  }



  render() {
    let  self = this
    let searchSongs = this.props.musicList.filter(function(song){
      return song.title.match(self.props.onSearch)
    })
    let items = searchSongs.map((value, index) => {
      return <Item key={index} title={value.title} />
    })
    return <div> { items } </div>
  }
}

ItemList.defaultProps = {
  musicList: [
    { title: 'Closer' },
    { title: 'This is What you come for' },
    { title: 'Dont let me down' },
    { title: 'Heathens' }
  ]
}

export default ItemList;
