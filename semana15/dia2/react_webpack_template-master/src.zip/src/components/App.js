import React, { Component } from 'react';
// Components
import SongFinder from './SongFinder';

class App extends Component {
  render() {
    return(
      <div>
        <SongFinder />
      </div>
    );
  }
}

export default App;
