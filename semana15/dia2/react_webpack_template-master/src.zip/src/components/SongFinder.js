import React, {Component} from 'react';
import ItemList from './result_list/ItemList';
import SearchBar from './search_bar/SearchBar';

class SongFinder extends Component {
  constructor(){
    super();
    this.state={
      song: ''
    }
    this.handleSearchSong= this.handleSearchSong.bind(this)
  }

  handleSearchSong(song){
    this.setState({song})
    console.log(this.state);
  }
  render(){
    return(
      <div>
        <SearchBar onSubmit={this.handleSearchSong}/>
        <ItemList onSearch={this.state.song}/>
      </div>
    );
  }
}

SongFinder.childcontextTypes ={

}

export default SongFinder;
