require_relative 'menu'

class Main
	Start.menu
end